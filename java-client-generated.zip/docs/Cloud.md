# Cloud

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cloudId** | **String** |  |  [optional]
**idClient** | **String** |  | 
**OS** | [**OSEnum**](#OSEnum) | Операционная система сервера | 
**RAM** | **String** |  | 
**CPU** | [**CPUEnum**](#CPUEnum) |  | 

<a name="OSEnum"></a>
## Enum: OSEnum
Name | Value
---- | -----
WINDOWS | &quot;Windows&quot;
LINUX | &quot;Linux&quot;

<a name="CPUEnum"></a>
## Enum: CPUEnum
Name | Value
---- | -----
XEON | &quot;Xeon&quot;
EPYC | &quot;EPYC&quot;
ARM | &quot;ARM&quot;
