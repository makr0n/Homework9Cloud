# CustomerCloudsApi

All URIs are relative to *http://localhost:8080/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getCustomerClouds**](CustomerCloudsApi.md#getCustomerClouds) | **GET** /customerClouds | Метод получения списка облачных серверов используемых Клиентом

<a name="getCustomerClouds"></a>
# **getCustomerClouds**
> CustomerClouds getCustomerClouds()

Метод получения списка облачных серверов используемых Клиентом

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CustomerCloudsApi;


CustomerCloudsApi apiInstance = new CustomerCloudsApi();
try {
    CustomerClouds result = apiInstance.getCustomerClouds();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomerCloudsApi#getCustomerClouds");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**CustomerClouds**](CustomerClouds.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: adplication/json, application/json

