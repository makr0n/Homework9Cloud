# CustomerCloud

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idClient** | **String** |  | 
**name** | **String** |  | 
